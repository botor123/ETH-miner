class MiningSimulator {
    constructor() {
        // Load saved state from localStorage
        const savedState = JSON.parse(localStorage.getItem('miningState')) || {
            isActive: false,
            hashrate: 0,
            earned: 0,
            activeTime: 0
        };
        
        this.isActive = savedState.isActive;
        this.hashrate = savedState.hashrate;
        this.earned = savedState.earned;
        this.activeTime = savedState.activeTime;
        this.timer = null;
        this.MIN_WITHDRAWAL = 0.03;
        
        this.withdrawalHistory = JSON.parse(localStorage.getItem('withdrawalHistory')) || [];
        
        this.initializeElements();
        this.initializeEventListeners();
        
        // Update display with saved values on load
        this.updateDisplay();
        
        // If mining was active when page was closed, restart it
        if (this.isActive) {
            this.startMining();
        }
        
        // Add upgrade modal elements
        this.upgradeModal = document.getElementById('upgrade-modal');
        this.paymentModal = document.getElementById('payment-modal');
        this.closeUpgradeModalButton = document.querySelector('.close-upgrade-modal');
        this.closePaymentModalButton = document.querySelector('.close-payment-modal');
        this.upgradeSelectButtons = document.querySelectorAll('.upgrade-select-button');
        this.walletAddressCopy = document.getElementById('wallet-address-copy');
        
        // Add payment modal event listeners
        this.closePaymentModalButton.addEventListener('click', () => this.hidePaymentModal());
        window.addEventListener('click', (e) => {
            if (e.target === this.paymentModal) {
                this.hidePaymentModal();
            }
        });
        
        this.walletAddressCopy.addEventListener('click', () => {
            const walletAddress = document.getElementById('wallet-address-text').textContent;
            navigator.clipboard.writeText(walletAddress).then(() => {
                alert('Wallet address copied to clipboard!');
            });
        });
        
        this.upgradeSelectButtons.forEach(button => {
            button.addEventListener('click', () => {
                this.hideUpgradeModal();
                this.showPaymentModal();
            });
        });
        
        // Add upgrade modal event listeners
        this.closeUpgradeModalButton.addEventListener('click', () => this.hideUpgradeModal());
        window.addEventListener('click', (e) => {
            if (e.target === this.upgradeModal) {
                this.hideUpgradeModal();
            }
        });
    }

    initializeElements() {
        this.startButton = document.getElementById('start-mining');
        this.stopButton = document.getElementById('stop-mining');
        this.hashrateDisplay = document.getElementById('hashrate');
        this.earnedDisplay = document.getElementById('earned');
        this.activeTimeDisplay = document.getElementById('active-time');
        this.availableBalanceDisplay = document.getElementById('available-balance');
        this.withdrawalAddress = document.getElementById('withdrawal-address');
        this.withdrawalAmount = document.getElementById('withdrawal-amount');
        this.withdrawButton = document.getElementById('withdraw');
        
        this.historyButton = document.getElementById('history-button');
        this.historyModal = document.getElementById('history-modal');
        this.closeModalButton = document.querySelector('.close-button');
        this.historyList = document.getElementById('history-list');
    }

    initializeEventListeners() {
        this.startButton.addEventListener('click', () => this.startMining());
        this.stopButton.addEventListener('click', () => this.stopMining());
        this.withdrawButton.addEventListener('click', () => this.withdraw());
        
        this.withdrawalAmount.addEventListener('input', () => {
            const amount = parseFloat(this.withdrawalAmount.value);
            if (amount < this.MIN_WITHDRAWAL) {
                this.withdrawalAmount.setCustomValidity(`Minimum withdrawal amount is ${this.MIN_WITHDRAWAL} ETH`);
            } else if (amount > this.earned) {
                this.withdrawalAmount.setCustomValidity(`Cannot withdraw more than your balance`);
            } else {
                this.withdrawalAmount.setCustomValidity('');
            }
        });
        
        this.historyButton.addEventListener('click', () => this.showHistory());
        this.closeModalButton.addEventListener('click', () => this.hideHistory());
        window.addEventListener('click', (e) => {
            if (e.target === this.historyModal) {
                this.hideHistory();
            }
        });
        
        // Update upgrade button click handler
        const upgradeButton = document.getElementById('upgrade-button');
        upgradeButton.addEventListener('click', () => this.showUpgradeModal());
    }

    startMining() {
        if (!this.isActive) {
            this.isActive = true;
            this.startButton.disabled = true;
            this.stopButton.disabled = false;
            
            this.timer = setInterval(() => {
                this.hashrate = Math.floor(Math.random() * 50) + 150; 
                this.earned += 0.000001; 
                this.activeTime += 1/3600; 
                
                this.updateDisplay();
                this.saveState(); // Save state after each update
            }, 1000);
        }
    }

    stopMining() {
        if (this.isActive) {
            this.isActive = false;
            this.startButton.disabled = false;
            this.stopButton.disabled = true;
            clearInterval(this.timer);
            this.hashrate = 0;
            this.updateDisplay();
            this.saveState(); // Save state after stopping
        }
    }

    updateDisplay() {
        this.hashrateDisplay.textContent = this.hashrate;
        this.earnedDisplay.textContent = this.earned.toFixed(6);
        this.activeTimeDisplay.textContent = this.activeTime.toFixed(2);
        this.availableBalanceDisplay.textContent = this.earned.toFixed(6);
    }

    validateEthAddress(address) {
        return /^0x[a-fA-F0-9]{40}$/.test(address);
    }

    withdraw() {
        const withdrawalAddr = this.withdrawalAddress.value;
        const amount = parseFloat(this.withdrawalAmount.value);

        if (!this.validateEthAddress(withdrawalAddr)) {
            alert("Please enter a valid ETH address!");
            return;
        }

        if (amount < this.MIN_WITHDRAWAL) {
            alert(`Minimum withdrawal amount is ${this.MIN_WITHDRAWAL} ETH!`);
            return;
        }

        if (amount > this.earned) {
            alert("Cannot withdraw more than your balance!");
            return;
        }

        const withdrawal = {
            address: withdrawalAddr,
            amount: amount,
            date: new Date().toISOString()
        };
        this.withdrawalHistory.unshift(withdrawal);
        localStorage.setItem('withdrawalHistory', JSON.stringify(this.withdrawalHistory));

        this.earned -= amount;
        this.updateDisplay();
        this.saveState(); // Save state after withdrawal
        alert(`Withdrawal request received!\n\nAddress: ${withdrawalAddr}\nAmount: ${amount} ETH`);
        
        this.withdrawalAddress.value = '';
        this.withdrawalAmount.value = '';
    }

    saveState() {
        const state = {
            isActive: this.isActive,
            hashrate: this.hashrate,
            earned: this.earned,
            activeTime: this.activeTime
        };
        localStorage.setItem('miningState', JSON.stringify(state));
    }

    showUpgradeModal() {
        this.upgradeModal.style.display = 'block';
    }

    hideUpgradeModal() {
        this.upgradeModal.style.display = 'none';
    }

    showPaymentModal() {
        this.paymentModal.style.display = 'block';
    }

    hidePaymentModal() {
        this.paymentModal.style.display = 'none';
    }

    showHistory() {
        this.updateHistoryDisplay();
        this.historyModal.style.display = 'block';
    }

    hideHistory() {
        this.historyModal.style.display = 'none';
    }

    updateHistoryDisplay() {
        this.historyList.innerHTML = '';
        
        if (this.withdrawalHistory.length === 0) {
            this.historyList.innerHTML = '<div class="no-history">No withdrawal history yet</div>';
            return;
        }

        this.withdrawalHistory.forEach(withdrawal => {
            const date = new Date(withdrawal.date);
            const formattedDate = date.toLocaleString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            const historyItem = document.createElement('div');
            historyItem.className = 'history-item';
            historyItem.innerHTML = `
                <div class="history-item-header">
                    <span class="history-amount">${withdrawal.amount} ETH</span>
                    <span class="history-date">${formattedDate}</span>
                </div>
                <div class="history-address">${withdrawal.address}</div>
            `;
            this.historyList.appendChild(historyItem);
        });
    }
}

// Add event listener for when the page is about to unload
window.addEventListener('beforeunload', () => {
    const simulator = document.querySelector('body').__miningSimulator;
    if (simulator) {
        simulator.saveState();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const simulator = new MiningSimulator();
    // Store reference to instance for beforeunload handler
    document.querySelector('body').__miningSimulator = simulator;
});